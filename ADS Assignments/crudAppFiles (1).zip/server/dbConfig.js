// dbConfig.js
const dbConfig = {
  host: "192.168.43.225",
  user: "root",
  password: "Jay@1234",
  port: 3306,
};

module.exports = dbConfig;
